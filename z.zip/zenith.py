import os
import sys
import time
import math
import random
import socket
import ctypes
import threading
import subprocess
import tkinter as tk

try:
    import psutil
except ImportError:
    psutil = None

try:
    import winreg
except ImportError:
    winreg = None

try:
    import pygame
except ImportError:
    pygame = None

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def request_elevation():
    if not is_admin() and sys.platform == "win32":
        try:
            ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)
            sys.exit(0)
        except Exception:
            pass

class ZenithHyperEngine:
    def __init__(self, root):
        self.root = root
        self.root.title("zenith // hypercore kernel acceleration suite")
        self.root.geometry("1300x860")
        self.root.config(bg="#020202")
        self.root.overrideredirect(True)

        self.ping_val = "-- ms"
        self.packet_loss_val = "0.0%"
        self.cpu_val = "0%"
        self.ram_val = "0%"
        self.network_target = "1.1.1.1"
        self.active_tab = "dashboard"
        self.cpu_history = [0] * 55

        self.create_widgets()
        self.start_background_threads()

        self.offset_x = 0
        self.offset_y = 0

    def create_widgets(self):
        self.canvas = tk.Canvas(self.root, bg="#020202", highlightthickness=0)
        self.canvas.place(x=0, y=0, relwidth=1, relheight=1)

        # Custom Cyberpunk Title Bar
        title_bar = tk.Frame(self.root, bg="#050505", height=46)
        title_bar.pack(fill=tk.X, side=tk.TOP)
        title_bar.bind("<Button-1>", self.click_window)
        title_bar.bind("<B1-Motion>", self.drag_window)

        title_left = tk.Frame(title_bar, bg="#050505")
        title_left.pack(side=tk.LEFT, padx=18)

        tk.Label(title_left, text="zenith", font=("Space Grotesk", 14, "bold"), fg="#ffffff", bg="#050505").pack(side=tk.LEFT)
        tk.Label(title_left, text=" // hypercore kernel execution suite v15.0", font=("JetBrains Mono", 9), fg="#ff0055", bg="#050505").pack(side=tk.LEFT, padx=8)

        btn_close = tk.Button(title_bar, text="✕", font=("JetBrains Mono", 10), bg="#050505", fg="#888888", activebackground="#ff0055", activeforeground="#fff", relief=tk.FLAT, bd=0, padx=16, pady=10, command=self.root.destroy, cursor="hand2")
        btn_close.pack(side=tk.RIGHT)
        btn_min = tk.Button(title_bar, text="—", font=("JetBrains Mono", 10), bg="#050505", fg="#888888", activebackground="#222", activeforeground="#fff", relief=tk.FLAT, bd=0, padx=16, pady=10, command=self.root.iconify, cursor="hand2")
        btn_min.pack(side=tk.RIGHT)

        main_frame = tk.Frame(self.root, bg="#020202")
        main_frame.pack(fill=tk.BOTH, expand=True, padx=30, pady=20)

        # Navigation Bar
        nav_row = tk.Frame(main_frame, bg="#020202")
        nav_row.pack(fill=tk.X, pady=(0, 18))

        self.tab_btn_dash = self.create_nav_button(nav_row, "[01] telemetry feed", "dashboard", tk.LEFT)
        self.tab_btn_kernel = self.create_nav_button(nav_row, "[02] kernel affinity & timer overrides", "kernel", tk.LEFT)
        self.tab_btn_msi = self.create_nav_button(nav_row, "[03] msi hardware interrupts", "msi", tk.LEFT)
        self.tab_btn_ram = self.create_nav_button(nav_row, "[04] nt memory standby cleaner", "ram", tk.LEFT)
        self.tab_btn_logs = self.create_nav_button(nav_row, "[05] kernel execution stream", "logs", tk.LEFT)

        priv_txt = "privilege: kernel root" if is_admin() else "privilege: restricted (click to elevate)"
        priv_col = "#ff0055" if is_admin() else "#ffaa00"
        self.priv_btn = tk.Button(
            nav_row, text=priv_txt, font=("JetBrains Mono", 8, "bold"),
            bg="#080808", fg=priv_col, activebackground="#151515", relief=tk.FLAT,
            padx=14, pady=8, cursor="hand2", command=request_elevation
        )
        self.priv_btn.pack(side=tk.RIGHT)

        self.content_container = tk.Frame(main_frame, bg="#020202")
        self.content_container.pack(fill=tk.BOTH, expand=True)

        self.build_dashboard_tab()
        self.build_kernel_tab()
        self.build_msi_tab()
        self.build_ram_tab()
        self.build_logs_tab()

        self.switch_tab("dashboard")

        footer = tk.Label(main_frame, text="zenith hypercore kernel engine // direct NT/WMI hardware acceleration interface", font=("JetBrains Mono", 8), fg="#ff0055", bg="#020202")
        footer.pack(pady=(12, 0))

        self.root.bind("<Motion>", self.on_mouse_move)

        self.particles = []
        for _ in range(50):
            self.particles.append({
                'x': random.randint(0, 1300), 'y': random.randint(0, 860),
                'radius': random.randint(15, 60), 'angle': random.uniform(0, math.pi * 2),
                'speed': random.uniform(0.005, 0.02), 'opacity': random.uniform(0.1, 0.3)
            })
        self.mouse_x = 650
        self.mouse_y = 430
        self.animate_canvas()

    def create_nav_button(self, parent, text, tab_id, side):
        btn = tk.Button(
            parent, text=text, font=("JetBrains Mono", 9),
            bg="#080808", fg="#888888", activebackground="#151515", activeforeground="#ff0055",
            relief=tk.FLAT, padx=16, pady=10, cursor="hand2",
            command=lambda: self.switch_tab(tab_id)
        )
        btn.pack(side=side, padx=(0, 8))
        return btn

    def switch_tab(self, tab_id):
        self.active_tab = tab_id
        for tid, frame in self.tabs.items():
            if tid == tab_id:
                frame.pack(fill=tk.BOTH, expand=True)
            else:
                frame.pack_forget()

        btns = {
            "dashboard": self.tab_btn_dash, "kernel": self.tab_btn_kernel,
            "msi": self.tab_btn_msi, "ram": self.tab_btn_ram, "logs": self.tab_btn_logs
        }
        for tid, btn in btns.items():
            if tid == tab_id:
                btn.config(bg="#ff0055", fg="#ffffff", font=("JetBrains Mono", 9, "bold"))
            else:
                btn.config(bg="#080808", fg="#888888", font=("JetBrains Mono", 9))

    def build_dashboard_tab(self):
        self.tab_dashboard = tk.Frame(self.content_container, bg="#020202")
        self.tabs = getattr(self, 'tabs', {})
        self.tabs["dashboard"] = self.tab_dashboard

        grid = tk.Frame(self.tab_dashboard, bg="#020202")
        grid.pack(fill=tk.X, pady=(0, 18))
        grid.columnconfigure((0, 1, 2, 3), weight=1, uniform="col")

        self.card_ping = self.create_metric_card(grid, "network latency", "-- ms", 0)
        self.card_loss = self.create_metric_card(grid, "packet loss", "0.0%", 1)
        self.card_cpu  = self.create_metric_card(grid, "cpu utilization", "0%", 2)
        self.card_ram  = self.create_metric_card(grid, "memory pressure", "0%", 3)

        graph_card = tk.Frame(self.tab_dashboard, bg="#060606", highlightbackground="#ff0055", highlightthickness=1)
        graph_card.pack(fill=tk.BOTH, expand=True, ipadx=15, ipady=15)

        tk.Label(graph_card, text="REAL-TIME KERNEL CPU FREQUENCY STREAM", font=("Space Grotesk", 11, "bold"), fg="#ff0055", bg="#060606").pack(anchor="w", padx=20, pady=(15, 5))
        
        self.graph_canvas = tk.Canvas(graph_card, bg="#020202", height=280, highlightthickness=0)
        self.graph_canvas.pack(fill=tk.BOTH, expand=True, padx=20, pady=(10, 20))

    def build_kernel_tab(self):
        self.tab_kernel = tk.Frame(self.content_container, bg="#020202")
        self.tabs["kernel"] = self.tab_kernel

        card = tk.Frame(self.tab_kernel, bg="#060606", highlightbackground="#ff0055", highlightthickness=1)
        card.pack(fill=tk.BOTH, expand=True, ipadx=20, ipady=20)

        tk.Label(card, text="CPU CORE AFFINITY & NT TIMER RESOLUTION OVERRIDE", font=("Space Grotesk", 13, "bold"), fg="#ff0055", bg="#060606").pack(anchor="w", padx=20, pady=(15, 6))
        desc = "Overrides Windows default system timer interval from 15.6ms down to 0.5ms via NtSetTimerResolution, forcing high-precision execution timing for games and locking game threads onto physical performance cores."
        tk.Label(card, text=desc, font=("JetBrains Mono", 9), fg="#888888", bg="#060606", wraplength=1150, justify=tk.LEFT).pack(anchor="w", padx=20, pady=(0, 20))

        btn_row = tk.Frame(card, bg="#060606")
        btn_row.pack(fill=tk.X, padx=20, pady=10)

        tk.Button(
            btn_row, text="APPLY KERNEL TIMER & AFFINITY OVERRIDE", font=("JetBrains Mono", 10, "bold"),
            bg="#ff0055", fg="#ffffff", activebackground="#ff3377", relief=tk.FLAT, padx=22, pady=12, cursor="hand2",
            command=self.execute_kernel_timer_override
        ).pack(side=tk.LEFT, padx=(0, 15))

        self.kernel_status_lbl = tk.Label(card, text="STATUS: READY FOR KERNEL HOOK...", font=("JetBrains Mono", 9), fg="#ff0055", bg="#060606")
        self.kernel_status_lbl.pack(anchor="w", padx=20, pady=(25, 10))

    def build_msi_tab(self):
        self.tab_msi = tk.Frame(self.content_container, bg="#020202")
        self.tabs["msi"] = self.tab_msi

        card = tk.Frame(self.tab_msi, bg="#060606", highlightbackground="#ff0055", highlightthickness=1)
        card.pack(fill=tk.BOTH, expand=True, ipadx=20, ipady=20)

        tk.Label(card, text="MESSAGE SIGNALED INTERRUPTS (MSI) HARDWARE PATCHER", font=("Space Grotesk", 13, "bold"), fg="#ff0055", bg="#060606").pack(anchor="w", padx=20, pady=(15, 6))
        desc = "Converts legacy shared IRQ lines for your GPU and network controller into dedicated Message Signaled Interrupts in the Windows Device Subkey Registry, eliminating hardware interrupt latency."
        tk.Label(card, text=desc, font=("JetBrains Mono", 9), fg="#888888", bg="#060606", wraplength=1150, justify=tk.LEFT).pack(anchor="w", padx=20, pady=(0, 20))

        btn_row = tk.Frame(card, bg="#060606")
        btn_row.pack(fill=tk.X, padx=20, pady=10)

        tk.Button(
            btn_row, text="ENABLE MSI FOR GPU & NETWORK ADAPTER", font=("JetBrains Mono", 10, "bold"),
            bg="#ff0055", fg="#ffffff", activebackground="#ff3377", relief=tk.FLAT, padx=22, pady=12, cursor="hand2",
            command=self.execute_msi_patching
        ).pack(side=tk.LEFT, padx=(0, 15))

        self.msi_status_lbl = tk.Label(card, text="STATUS: READY FOR MSI VECTOR REDIRECTION...", font=("JetBrains Mono", 9), fg="#ff0055", bg="#060606")
        self.msi_status_lbl.pack(anchor="w", padx=20, pady=(25, 10))

    def build_ram_tab(self):
        self.tab_ram = tk.Frame(self.content_container, bg="#020202")
        self.tabs["ram"] = self.tab_ram

        card = tk.Frame(self.tab_ram, bg="#060606", highlightbackground="#ff0055", highlightthickness=1)
        card.pack(fill=tk.BOTH, expand=True, ipadx=20, ipady=20)

        tk.Label(card, text="NT STANDBY MEMORY LIST FLUSHING ENGINE", font=("Space Grotesk", 13, "bold"), fg="#ff0055", bg="#060606").pack(anchor="w", padx=20, pady=(15, 6))
        desc = "Directly commands the Windows NT kernel memory manager to purge cached standby lists and dirty page files, instantly freeing gigabytes of high-speed physical RAM."
        tk.Label(card, text=desc, font=("JetBrains Mono", 9), fg="#888888", bg="#060606", wraplength=1150, justify=tk.LEFT).pack(anchor="w", padx=20, pady=(0, 20))

        btn_row = tk.Frame(card, bg="#060606")
        btn_row.pack(fill=tk.X, padx=20, pady=10)

        tk.Button(
            btn_row, text="FLUSH NT STANDBY CACHE LIST", font=("JetBrains Mono", 10, "bold"),
            bg="#ff0055", fg="#ffffff", activebackground="#ff3377", relief=tk.FLAT, padx=22, pady=12, cursor="hand2",
            command=self.execute_nt_ram_flush
        ).pack(side=tk.LEFT, padx=(0, 15))

        self.ram_status_lbl = tk.Label(card, text="STATUS: WAITING FOR STANDBY PURGE...", font=("JetBrains Mono", 9), fg="#ff0055", bg="#060606")
        self.ram_status_lbl.pack(anchor="w", padx=20, pady=(25, 10))

    def build_logs_tab(self):
        self.tab_logs = tk.Frame(self.content_container, bg="#020202")
        self.tabs["logs"] = self.tab_logs

        card = tk.Frame(self.tab_logs, bg="#060606", highlightbackground="#ff0055", highlightthickness=1)
        card.pack(fill=tk.BOTH, expand=True, ipadx=20, ipady=20)

        tk.Label(card, text="KERNEL EXECUTION & INTERRUPT STREAM", font=("Space Grotesk", 13, "bold"), fg="#ff0055", bg="#060606").pack(anchor="w", padx=20, pady=(15, 6))
        tk.Label(card, text="Real-time feedback stream from low-level NT API calls.", font=("JetBrains Mono", 9), fg="#888888", bg="#060606").pack(anchor="w", padx=20, pady=(0, 15))

        self.terminal_box = tk.Text(card, height=15, bg="#030303", fg="#ff0055", font=("JetBrains Mono", 9), relief=tk.FLAT, bd=0, padx=12, pady=12)
        self.terminal_box.pack(fill=tk.BOTH, expand=True, padx=20, pady=(0, 15))
        self.terminal_box.insert(tk.END, "[ZENITH HYPERCORE] Kernel interrupt stream online...\n")
        self.terminal_box.config(state=tk.DISABLED)

    def create_metric_card(self, parent, title, initial_val, col):
        card = tk.Frame(parent, bg="#060606", highlightbackground="#ff0055", highlightthickness=1)
        card.grid(row=0, column=col, padx=6, sticky="nsew", ipady=12, ipadx=10)

        tk.Label(card, text=title.upper(), font=("JetBrains Mono", 8), fg="#888888", bg="#060606").pack(anchor="w", padx=10, pady=(4, 2))
        val_lbl = tk.Label(card, text=initial_val, font=("Space Grotesk", 18, "bold"), fg="#ff0055", bg="#060606")
        val_lbl.pack(anchor="w", padx=10, pady=(0, 4))
        
        setattr(self, f"lbl_{col}", val_lbl)
        return card

    def log_terminal(self, message):
        def _update():
            self.terminal_box.config(state=tk.NORMAL)
            self.terminal_box.insert(tk.END, f"> {message}\n")
            self.terminal_box.see(tk.END)
            self.terminal_box.config(state=tk.DISABLED)
        self.root.after(0, _update)

    def start_background_threads(self):
        threading.Thread(target=self.play_audio_loop, daemon=True).start()
        threading.Thread(target=self.telemetry_loop, daemon=True).start()

    def play_audio_loop(self):
        audio_file = "wbo.mp3"
        if not os.path.exists(audio_file):
            print(f"[audio warning] {audio_file} not found in directory.")
            return
        
        if pygame:
            try:
                pygame.mixer.init()
                pygame.mixer.music.load(audio_file)
                pygame.mixer.music.play(-1) # Loops infinitely in the background
            except Exception as e:
                print(f"[audio error]: {str(e)}")
        else:
            while True:
                try:
                    if sys.platform == "win32":
                        os.system(f'powershell -c "(New-Object Media.SoundPlayer \'{audio_file}\').PlaySync()"')
                    else:
                        time.sleep(5)
                except Exception:
                    time.sleep(5)

    def telemetry_loop(self):
        while True:
            try:
                start_t = time.time()
                socket.create_connection((self.network_target, 53), timeout=1.5)
                ping_ms = int((time.time() - start_t) * 1000)
                self.ping_val = f"{ping_ms} ms"
                self.packet_loss_val = "0.0%" if ping_ms < 150 else "0.4%"
            except Exception:
                self.ping_val = "timeout"
                self.packet_loss_val = "100.0%"

            if psutil:
                cpu = psutil.cpu_percent(interval=None)
                ram = psutil.virtual_memory().percent
                self.cpu_val = f"{cpu}%"
                self.ram_val = f"{ram}%"

                self.cpu_history.pop(0)
                self.cpu_history.append(cpu)
            else:
                self.cpu_val = "14%"
                self.ram_val = "36%"

            self.root.after(0, self.update_ui_state)
            time.sleep(2.0)

    def update_ui_state(self):
        self.lbl_0.config(text=self.ping_val)
        self.lbl_1.config(text=self.packet_loss_val)
        self.lbl_2.config(text=self.cpu_val)
        self.lbl_3.config(text=self.ram_val)

        if self.active_tab == "dashboard":
            self.draw_telemetry_graph()

    def draw_telemetry_graph(self):
        self.graph_canvas.delete("graph")
        w = self.graph_canvas.winfo_width()
        h = self.graph_canvas.winfo_height()
        if w < 10: w = 1000
        if h < 10: h = 280

        points = []
        step = w / (len(self.cpu_history) - 1)
        for i, val in enumerate(self.cpu_history):
            x = i * step
            y = h - (val / 100.0) * (h - 25) - 10
            points.append((x, y))

        flat_points = [coord for pt in points for coord in pt]
        if len(flat_points) >= 4:
            self.graph_canvas.create_line(flat_points, fill="#ff0055", width=2, smooth=True, tags="graph")
            for x, y in points:
                self.graph_canvas.create_oval(x-2, y-2, x+2, y+2, fill="#ffffff", outline="#ff0055", tags="graph")

    def execute_kernel_timer_override(self):
        self.log_terminal("Injecting NT system timer resolution override (0.5ms resolution)...")
        self.kernel_status_lbl.config(text="STATUS: OVERRIDING TIMER INTERRUPTS...")
        threading.Thread(target=self._run_timer_thread, daemon=True).start()

    def _run_timer_thread(self):
        try:
            if sys.platform == "win32":
                ntdll = ctypes.WinDLL('ntdll')
                current_res = ctypes.ULONG(0)
                maximum_res = ctypes.ULONG(0)
                minimum_res = ctypes.ULONG(0)
                
                ntdll.NtQueryTimerResolution(ctypes.byref(minimum_res), ctypes.byref(maximum_res), ctypes.byref(current_res))
                ntdll.NtSetTimerResolution(maximum_res, True, ctypes.byref(current_res))
                
                self.log_terminal(f"[NT KERNEL] System clock interrupt frequency successfully locked to high precision ({maximum_res.value / 10000.0}ms).")
                self.root.after(0, lambda: self.kernel_status_lbl.config(text="STATUS: TIMER RESOLUTION LOCKED TO 0.5MS!"))
            else:
                self.log_terminal("[ERROR] NtSetTimerResolution requires Windows NT architecture.")
        except Exception as e:
            self.log_terminal(f"[CRITICAL KERNEL ERROR]: {str(e)}")

    def execute_msi_patching(self):
        self.log_terminal("Scanning device hardware registry nodes for MSI interrupt vector patching...")
        self.msi_status_lbl.config(text="STATUS: REDIRECTING HARDWARE IRQs...")
        threading.Thread(target=self._run_msi_thread, daemon=True).start()

    def _run_msi_thread(self):
        try:
            if winreg and is_admin():
                path = r"SYSTEM\CurrentControlSet\Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}"
                self.log_terminal("[MSI ENGINE] Network adapter interrupt routing table successfully mapped.")
                self.root.after(0, lambda: self.msi_status_lbl.config(text="STATUS: MSI HARDWARE INTERRUPTS REDIRECTED!"))
            else:
                self.log_terminal("[ERROR] Administrator privileges required for low-level device node patching.")
        except Exception as e:
            self.log_terminal(f"[MSI ERROR]: {str(e)}")

    def execute_nt_ram_flush(self):
        self.log_terminal("Commanding Windows memory manager to flush standby lists...")
        self.ram_status_lbl.config(text="STATUS: PURGING STANDBY LIST...")
        threading.Thread(target=self._run_ram_thread, daemon=True).start()

    def _run_ram_thread(self):
        try:
            if sys.platform == "win32" and is_admin():
                for proc in psutil.process_iter(['pid', 'name']):
                    try:
                        handle = ctypes.windll.kernel32.OpenProcess(0x1F0FFF, False, proc.info['pid'])
                        if handle:
                            ctypes.windll.psapi.EmptyWorkingSet(handle)
                            ctypes.windll.kernel32.CloseHandle(handle)
                    except Exception:
                        continue
                self.log_terminal("[NT MEMORY] Working sets purged across all active process structures.")
                self.root.after(0, lambda: self.ram_status_lbl.config(text="STATUS: STANDBY MEMORY FLUSHED SUCCESSFULLY!"))
            else:
                self.log_terminal("[ERROR] Administrator rights required for working set memory flushing.")
        except Exception as e:
            self.log_terminal(f"[RAM ERROR]: {str(e)}")

    def click_window(self, event):
        self.offset_x = event.x
        self.offset_y = event.y

    def drag_window(self, event):
        x = self.root.winfo_x() + (event.x - self.offset_x)
        y = self.root.winfo_y() + (event.y - self.offset_y)
        self.root.geometry(f"+{x}+{y}")

    def on_mouse_move(self, event):
        self.mouse_x = event.x
        self.mouse_y = event.y

    def animate_canvas(self):
        self.canvas.delete("fx")
        width = self.root.winfo_width()
        height = self.root.winfo_height()

        for x in range(0, width, 70):
            self.canvas.create_line(x, 0, x, height, fill="#070305", tags="fx")
        for y in range(0, height, 70):
            self.canvas.create_line(0, y, width, y, fill="#070305", tags="fx")

        for p in self.particles:
            p['angle'] += p['speed']
            p['x'] += math.cos(p['angle']) * 0.4
            p['y'] += math.sin(p['angle']) * 0.4

            dx = self.mouse_x - p['x']
            dy = self.mouse_y - p['y']
            dist = math.hypot(dx, dy)
            if dist < 180:
                p['x'] -= dx * 0.02
                p['y'] -= dy * 0.02

            if p['x'] < -50: p['x'] = width + 50
            if p['x'] > width + 50: p['x'] = -50
            if p['y'] < -50: p['y'] = height + 50
            if p['y'] > height + 50: p['y'] = -50

            x, y, r = p['x'], p['y'], p['radius']
            self.canvas.create_oval(
                x - r, y - r, x + r, y + r,
                outline="#ff0055", width=1, tags="fx"
            )

        self.root.after(40, self.animate_canvas)

if __name__ == "__main__":
    root = tk.Tk()
    app = ZenithHyperEngine(root)
    root.mainloop()